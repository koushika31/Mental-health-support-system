
import { RASA_API_URL } from "../config/config";
import { Mood } from "../types";

// In a real implementation, this would connect to a Rasa server
// For the demo, we'll simulate responses
export const sendMessageToRasa = async (message: string): Promise<{ text: string; mood?: Mood }> => {
  console.log("Sending to Rasa:", message);
  
  // Simulate sending to Rasa and getting a response
  return new Promise((resolve) => {
    setTimeout(() => {
      // For demo: detect simple keywords to determine sentiment
      let mood: Mood = "neutral";
      let response = "I understand. How else can I help you today?";
      
      const lowerMsg = message.toLowerCase();
      
      if (lowerMsg.includes("happy") || lowerMsg.includes("good") || lowerMsg.includes("great") || lowerMsg.includes("joy")) {
        mood = "happy";
        response = "I'm glad you're feeling good! Would you like to see some videos to maintain this positive mood?";
      } else if (lowerMsg.includes("sad") || lowerMsg.includes("down") || lowerMsg.includes("depressed") || lowerMsg.includes("unhappy")) {
        mood = "sad";
        response = "I'm sorry you're feeling down. Would you like to see some videos that might help lift your spirits?";
      } else if (lowerMsg.includes("angry") || lowerMsg.includes("mad") || lowerMsg.includes("frustrat") || lowerMsg.includes("upset")) {
        mood = "angry";
        response = "I understand you're feeling frustrated. Would you like to see some calming videos that might help?";
      }
      
      resolve({ text: response, mood });
    }, 500);
  });
};

export const analyzeSentiment = async (message: string): Promise<Mood> => {
  // In a real app, this would call the Rasa NLU to analyze sentiment
  // For the demo, we'll use a simple keyword approach
  const lowerMsg = message.toLowerCase();
  
  if (lowerMsg.includes("happy") || lowerMsg.includes("good") || lowerMsg.includes("great") || lowerMsg.includes("joy")) {
    return "happy";
  } else if (lowerMsg.includes("sad") || lowerMsg.includes("down") || lowerMsg.includes("depressed") || lowerMsg.includes("unhappy")) {
    return "sad";
  } else if (lowerMsg.includes("angry") || lowerMsg.includes("mad") || lowerMsg.includes("frustrat") || lowerMsg.includes("upset")) {
    return "angry";
  }
  
  return "neutral";
};
