
import { AUTH_TOKEN_KEY } from "../config/config";

export const login = async (email: string, password: string) => {
  // In a real app, this would make an API call to your backend
  // Using a placeholder for demo purposes
  return new Promise<{ token: string; user: { id: string; username: string; email: string } }>((resolve) => {
    setTimeout(() => {
      const token = `mock-token-${Math.random().toString(36).substr(2, 9)}`;
      const user = { id: "user-1", username: email.split('@')[0], email };
      
      localStorage.setItem(AUTH_TOKEN_KEY, token);
      
      resolve({ token, user });
    }, 800);
  });
};

export const register = async (username: string, email: string, password: string) => {
  // In a real app, this would make an API call to register the user
  return new Promise<{ token: string; user: { id: string; username: string; email: string } }>((resolve) => {
    setTimeout(() => {
      const token = `mock-token-${Math.random().toString(36).substr(2, 9)}`;
      const user = { id: `user-${Math.random().toString(36).substr(2, 9)}`, username, email };
      
      localStorage.setItem(AUTH_TOKEN_KEY, token);
      
      resolve({ token, user });
    }, 1000);
  });
};

export const logout = () => {
  localStorage.removeItem(AUTH_TOKEN_KEY);
};

export const isAuthenticated = (): boolean => {
  return !!localStorage.getItem(AUTH_TOKEN_KEY);
};
