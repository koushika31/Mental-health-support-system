
import { Mood, Video } from "../types";
import { VIDEO_RECOMMENDATIONS } from "../config/config";

export const getVideoRecommendations = async (mood: Mood, limit: number = 3): Promise<Video[]> => {
  // In a real app, this would fetch videos from an API based on the mood
  // For demo purposes, we'll use our predefined videos
  return new Promise((resolve) => {
    setTimeout(() => {
      const videos = VIDEO_RECOMMENDATIONS[mood] || VIDEO_RECOMMENDATIONS.neutral;
      resolve(videos.slice(0, limit));
    }, 300);
  });
};

export const saveUserFeedback = async (videoId: string, rating: number, comment?: string): Promise<void> => {
  // In a real app, this would send feedback to an API
  console.log("Saving feedback:", { videoId, rating, comment });
  return Promise.resolve();
};

