
import { Mood, Video } from "../types";

export const RASA_API_URL = "http://localhost:5005";

export const AUTH_TOKEN_KEY = "vibe_bot_auth_token";

export const VIDEO_RECOMMENDATIONS: Record<Mood, Video[]> = {
  happy: [
    {
      id: "happy-1",
      title: "VJ Siddhu - Positive Mindset",
      description: "Motivational video about maintaining a positive mindset",
      url: "https://www.youtube.com/embed/MKEJGeYA9aU",
      mood: "happy",
      thumbnailUrl: "https://picsum.photos/id/25/300/200",
      language: "Tamil"
    },
    {
      id: "happy-2",
      title: "Tamil Success Motivation",
      description: "Tamil motivation by VJ Siddhu about achieving success",
      url: "https://www.youtube.com/embed/08jW0FYqCOA",
      mood: "happy",
      thumbnailUrl: "https://picsum.photos/id/28/300/200",
      language: "Tamil"
    },
    {
      id: "happy-3",
      title: "Tamil Motivational Song",
      description: "Powerful Tamil motivational song for success",
      url: "https://www.youtube.com/embed/0ExmHQRdjYs",
      mood: "happy",
      thumbnailUrl: "https://picsum.photos/id/29/300/200",
      language: "Tamil"
    },
  ],
  sad: [
    {
      id: "sad-1",
      title: "Never Give Up - Tamil Motivation",
      description: "Inspiring message about overcoming difficult times",
      url: "https://www.youtube.com/embed/knOSoYgAKpI",
      mood: "sad",
      thumbnailUrl: "https://picsum.photos/id/22/300/200",
      language: "Tamil"
    },
    {
      id: "sad-2",
      title: "Life Motivation - VJ Siddhu",
      description: "Powerful Tamil motivation for tough times",
      url: "https://www.youtube.com/embed/DSvmBvBwkWo",
      mood: "sad",
      thumbnailUrl: "https://picsum.photos/id/24/300/200",
      language: "Tamil"
    },
    {
      id: "sad-3",
      title: "Soothing Tamil Song",
      description: "Uplifting Tamil song for difficult moments",
      url: "https://www.youtube.com/embed/MFNJw2OVK1k",
      mood: "sad",
      thumbnailUrl: "https://picsum.photos/id/26/300/200",
      language: "Tamil"
    },
  ],
  neutral: [
    {
      id: "neutral-1",
      title: "Daily Motivation - VJ Siddhu",
      description: "Start your day with positive thoughts",
      url: "https://www.youtube.com/embed/ZbZSe6N_BXs",
      mood: "neutral",
      thumbnailUrl: "https://picsum.photos/id/30/300/200",
      language: "Tamil"
    },
    {
      id: "neutral-2",
      title: "Self Improvement Tips - Tamil",
      description: "Practical advice for personal growth in Tamil",
      url: "https://www.youtube.com/embed/NKX5f6iXmRw",
      mood: "neutral",
      thumbnailUrl: "https://picsum.photos/id/31/300/200",
      language: "Tamil"
    },
    {
      id: "neutral-3",
      title: "Tamil Mindfulness Practice",
      description: "Tamil guidance for mental peace and clarity",
      url: "https://www.youtube.com/embed/5GLQacNZpnY",
      mood: "neutral",
      thumbnailUrl: "https://picsum.photos/id/32/300/200",
      language: "Tamil"
    },
  ],
  angry: [
    {
      id: "angry-1",
      title: "Anger Management - Tamil",
      description: "How to control and channel anger positively",
      url: "https://www.youtube.com/embed/vCq-VHQPIjY",
      mood: "angry",
      thumbnailUrl: "https://picsum.photos/id/33/300/200",
      language: "Tamil"
    },
    {
      id: "angry-2",
      title: "Peace of Mind - VJ Siddhu",
      description: "Calming Tamil motivation for stress relief",
      url: "https://www.youtube.com/embed/XON-WrZcNM0",
      mood: "angry",
      thumbnailUrl: "https://picsum.photos/id/34/300/200",
      language: "Tamil"
    },
    {
      id: "angry-3",
      title: "Relaxing Tamil Music",
      description: "Soothing Tamil music for emotional balance",
      url: "https://www.youtube.com/embed/F4yAHGGI7Xc",
      mood: "angry",
      thumbnailUrl: "https://picsum.photos/id/35/300/200",
      language: "Tamil"
    },
  ],
};
