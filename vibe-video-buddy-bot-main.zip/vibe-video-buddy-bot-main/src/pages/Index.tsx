import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { isAuthenticated } from '@/services/authService';
import Header from '@/components/layout/Header';

const Index = () => {
  const navigate = useNavigate();
  const isLoggedIn = isAuthenticated();
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 flex flex-col">
        <section className="bg-gradient-to-b from-background to-accent/20 py-20 px-4 text-center">
          <div className="container mx-auto max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-700">
              Mental Health Chatbot Assistant
            </h1>
            <p className="text-lg md:text-xl mb-8 text-muted-foreground">
              Chat with our AI assistant to improve your mental wellbeing through personalized Tamil music recommendations
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {isLoggedIn ? (
                <Button 
                  size="lg" 
                  className="px-8 py-6 text-lg animate-pulse-gentle"
                  onClick={() => navigate('/chat')}
                >
                  Start Chatting
                </Button>
              ) : (
                <>
                  <Button 
                    variant="outline" 
                    size="lg" 
                    className="px-8"
                    onClick={() => navigate('/login')}
                  >
                    Login
                  </Button>
                  <Button 
                    size="lg" 
                    className="px-8 animate-pulse-gentle"
                    onClick={() => navigate('/register')}
                  >
                    Sign Up Free
                  </Button>
                </>
              )}
            </div>
          </div>
        </section>
        
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-6xl">
            <h2 className="text-3xl font-bold mb-10 text-center">How It Works</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              <FeatureCard 
                number={1}
                title="Chat Naturally"
                description="Have a natural conversation with our AI chatbot about your day and feelings"
              />
              <FeatureCard 
                number={2}
                title="Emoji Selection"
                description="Click on emojis to directly express your mood without typing"
              />
              <FeatureCard 
                number={3}
                title="Video Recommendations"
                description="Get personalized video recommendations based on your current mood"
              />
            </div>
          </div>
        </section>
        
        <section className="py-16 px-4 bg-accent/20">
          <div className="container mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Feel Better?</h2>
            <p className="text-lg mb-8">
              Join thousands of users who have improved their mood with our personalized video recommendations.
            </p>
            
            <Button 
              size="lg" 
              className="px-8 py-6 text-lg"
              onClick={() => isLoggedIn ? navigate('/chat') : navigate('/register')}
            >
              {isLoggedIn ? "Start Chatting Now" : "Get Started Free"}
            </Button>
          </div>
        </section>
      </main>
      
      <footer className="bg-muted/20 py-6 text-center text-sm text-muted-foreground">
        <p>© 2025 Vibe Video Buddy. All rights reserved.</p>
      </footer>
    </div>
  );
};

interface FeatureCardProps {
  number: number;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ number, title, description }) => {
  return (
    <div className="flex flex-col items-center text-center p-6">
      <div className="bg-primary/10 w-14 h-14 rounded-full flex items-center justify-center mb-4">
        <span className="text-primary font-bold text-xl">{number}</span>
      </div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  );
};

export default Index;
