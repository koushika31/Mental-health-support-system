
import React from 'react';
import RegisterForm from '@/components/auth/RegisterForm';
import Header from '@/components/layout/Header';

const RegisterPage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 flex items-center justify-center p-4 bg-accent/10">
        <RegisterForm />
      </main>
    </div>
  );
};

export default RegisterPage;
