
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Message, Mood } from '@/types';
import { isAuthenticated } from '@/services/authService';
import { sendMessageToRasa, analyzeSentiment } from '@/services/rasaService';
import Header from '@/components/layout/Header';
import ChatMessage from '@/components/chat/ChatMessage';
import ChatInput from '@/components/chat/ChatInput';
import VideoRecommendations from '@/components/video/VideoRecommendations';

const ChatPage: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentMood, setCurrentMood] = useState<Mood>("neutral");
  const [activeTab, setActiveTab] = useState("chat");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  
  useEffect(() => {
    if (!isAuthenticated()) {
      navigate('/login');
      return;
    }
    
    // Add initial bot message
    const initialMessage: Message = {
      id: "welcome-msg",
      sender: "bot",
      text: "Hi there! I'm your Vibe Video Buddy. How are you feeling today? You can type a message or click on an emoji to let me know.",
      timestamp: new Date(),
    };
    
    setMessages([initialMessage]);
  }, [navigate]);
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleSendMessage = async (text: string) => {
    // Add user message to chat
    const userMessageId = `msg-${Date.now()}`;
    const userMessage: Message = {
      id: userMessageId,
      sender: "user",
      text,
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, userMessage]);
    setLoading(true);
    
    try {
      // Analyze sentiment
      const mood = await analyzeSentiment(text);
      
      // Update user message with detected mood
      setMessages(prev => 
        prev.map(msg => 
          msg.id === userMessageId ? { ...msg, mood } : msg
        )
      );
      
      // Set current mood based on user message
      setCurrentMood(mood);
      
      // Get bot response
      const botResponse = await sendMessageToRasa(text);
      
      // Add bot response to chat
      const botMessage: Message = {
        id: `bot-${Date.now()}`,
        sender: "bot",
        text: botResponse.text,
        timestamp: new Date(),
        mood: botResponse.mood || mood,
      };
      
      setMessages(prev => [...prev, botMessage]);
      
      // Switch to video recommendations tab
      if (activeTab === "chat") {
        setTimeout(() => {
          setActiveTab("videos");
        }, 1000);
      }
    } catch (error) {
      console.error('Error processing message:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleMoodSelection = async (mood: Mood) => {
    setCurrentMood(mood);
    
    // Add user emoji selection message
    const emojiMap = {
      happy: "😊 I'm feeling happy!",
      sad: "😔 I'm feeling sad.",
      neutral: "😐 I'm feeling neutral.",
      angry: "😠 I'm feeling angry.",
    };
    
    await handleSendMessage(emojiMap[mood]);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 flex flex-col p-4 bg-accent/10">
        <Card className="w-full max-w-5xl mx-auto shadow-lg flex-1 flex flex-col">
          <Tabs 
            value={activeTab} 
            onValueChange={setActiveTab} 
            className="flex-1 flex flex-col"
          >
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="chat">Chat</TabsTrigger>
              <TabsTrigger value="videos">Video Recommendations</TabsTrigger>
            </TabsList>
            
            <TabsContent value="chat" className="flex-1 flex flex-col">
              <CardContent className="p-4 flex-1 overflow-y-auto chat-container">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <ChatMessage key={message.id} message={message} />
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              </CardContent>
              
              <Separator />
              
              <ChatInput 
                onSendMessage={handleSendMessage} 
                onSelectMood={handleMoodSelection}
                isLoading={loading}
              />
            </TabsContent>
            
            <TabsContent value="videos" className="flex-1 overflow-y-auto">
              <div className="p-4 mb-4">
                <h2 className="text-2xl font-bold">Recommended for 
                  <span className={`ml-2 ${
                    currentMood === 'happy' ? 'text-mood-happy' :
                    currentMood === 'sad' ? 'text-mood-sad' :
                    currentMood === 'angry' ? 'text-mood-angry' :
                    'text-mood-neutral'
                  }`}>
                    {currentMood} mood
                  </span>
                </h2>
                <p className="text-muted-foreground text-sm mt-1">
                  Videos selected to match how you're feeling right now
                </p>
              </div>
              
              <VideoRecommendations mood={currentMood} />
            </TabsContent>
          </Tabs>
        </Card>
      </main>
    </div>
  );
};

export default ChatPage;
