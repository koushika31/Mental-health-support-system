
import React from 'react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { logout, isAuthenticated } from '@/services/authService';
import { useToast } from '@/components/ui/use-toast';

const Header: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const isLoggedIn = isAuthenticated();
  
  const handleLogout = () => {
    logout();
    toast({
      title: "Logged out successfully",
      description: "You have been logged out of your account.",
    });
    navigate('/');
  };
  
  return (
    <header className="bg-background border-b py-3 px-4 flex items-center justify-between">
      <div className="flex items-center">
        <h1 
          className="text-xl font-bold text-primary cursor-pointer"
          onClick={() => navigate('/')}
        >
          Mental Health Chatbot
        </h1>
      </div>
      
      <div className="flex gap-3">
        {isLoggedIn ? (
          <>
            <Button 
              variant="outline" 
              onClick={() => navigate('/chat')}
            >
              Chat
            </Button>
            <Button 
              variant="ghost" 
              onClick={handleLogout}
            >
              Logout
            </Button>
          </>
        ) : (
          <>
            <Button 
              variant="outline"
              onClick={() => navigate('/login')}
            >
              Login
            </Button>
            <Button 
              onClick={() => navigate('/register')}
            >
              Register
            </Button>
          </>
        )}
      </div>
    </header>
  );
};

export default Header;
