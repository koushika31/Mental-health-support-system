
import React, { useEffect, useState } from 'react';
import { Video, Mood } from '@/types';
import { getVideoRecommendations } from '@/services/videoService';
import VideoCard from './VideoCard';

interface VideoRecommendationsProps {
  mood: Mood;
}

const VideoRecommendations: React.FC<VideoRecommendationsProps> = ({ mood }) => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const fetchVideos = async () => {
      setLoading(true);
      try {
        const recommendedVideos = await getVideoRecommendations(mood);
        setVideos(recommendedVideos);
      } catch (error) {
        console.error('Error fetching video recommendations:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchVideos();
  }, [mood]);
  
  if (loading) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        Finding perfect videos for you...
      </div>
    );
  }
  
  if (videos.length === 0) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        No video recommendations available.
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-2">
      {videos.map((video) => (
        <VideoCard key={video.id} video={video} />
      ))}
    </div>
  );
};

export default VideoRecommendations;
