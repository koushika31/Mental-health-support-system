
import React from 'react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Video } from '@/types';
import { ThumbsUp, ThumbsDown, Music } from 'lucide-react';
import { saveUserFeedback } from '@/services/videoService';
import { useToast } from '@/components/ui/use-toast';

interface VideoCardProps {
  video: Video;
}

const VideoCard: React.FC<VideoCardProps> = ({ video }) => {
  const { toast } = useToast();
  
  const handleFeedback = async (rating: number) => {
    try {
      await saveUserFeedback(video.id, rating);
      toast({
        title: "Feedback received",
        description: "Thank you for your feedback!",
      });
    } catch (error) {
      console.error('Error saving feedback:', error);
    }
  };
  
  const getMoodColor = () => {
    switch (video.mood) {
      case 'happy': return 'bg-mood-happy';
      case 'sad': return 'bg-mood-sad';
      case 'angry': return 'bg-mood-angry';
      default: return 'bg-mood-neutral';
    }
  };
  
  return (
    <Card className="video-card w-full overflow-hidden shadow-md">
      <div className="relative">
        <div className={`absolute top-2 right-2 ${getMoodColor()} text-white text-xs px-2 py-1 rounded-full`}>
          {video.mood}
        </div>
        {video.language && (
          <div className="absolute top-2 left-2 bg-primary bg-opacity-80 text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
            <Music className="h-3 w-3" />
            {video.language}
          </div>
        )}
        {video.thumbnailUrl ? (
          <img 
            src={video.thumbnailUrl} 
            alt={video.title} 
            className="w-full h-40 object-cover"
          />
        ) : (
          <div className={`w-full h-40 flex items-center justify-center ${getMoodColor()} bg-opacity-20`}>
            <span className="text-lg font-medium">{video.title}</span>
          </div>
        )}
      </div>
      
      <CardContent className="p-4">
        <h3 className="font-bold mb-1 truncate">{video.title}</h3>
        <p className="text-sm text-muted-foreground line-clamp-2">{video.description}</p>
        
        <div className="mt-3">
          <Button 
            variant="outline" 
            className="w-full text-sm" 
            onClick={() => window.open(video.url, '_blank')}
          >
            Listen Now
          </Button>
        </div>
      </CardContent>
      
      <CardFooter className="px-4 py-2 border-t flex justify-between bg-muted/30">
        <p className="text-xs text-muted-foreground">Was this helpful?</p>
        <div className="flex gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-7 w-7 p-0" 
            onClick={() => handleFeedback(1)}
          >
            <ThumbsUp className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-7 w-7 p-0" 
            onClick={() => handleFeedback(-1)}
          >
            <ThumbsDown className="h-4 w-4" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default VideoCard;

