
import React from 'react';
import { cn } from '@/lib/utils';
import { Message } from '@/types';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.sender === 'user';
  const moodColor = message.mood ? getMoodColor(message.mood) : '';
  
  return (
    <div className={cn(
      "flex items-start gap-2 mb-4 chat-message",
      isUser ? "flex-row-reverse" : ""
    )}>
      <Avatar className={cn(
        "h-8 w-8",
        isUser ? "bg-primary" : "bg-secondary" 
      )}>
        <AvatarFallback>
          {isUser ? 'U' : 'B'}
        </AvatarFallback>
      </Avatar>
      
      <div className={cn(
        "px-4 py-2 rounded-lg max-w-[80%]",
        isUser 
          ? "bg-primary text-primary-foreground rounded-tr-none" 
          : "bg-muted rounded-tl-none"
      )}>
        <p className="text-sm">{message.text}</p>
        {message.mood && !isUser && (
          <div className="mt-1 text-xs opacity-70">
            Detected mood: <span className={`font-medium ${moodColor}`}>
              {message.mood}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

const getMoodColor = (mood: string): string => {
  switch (mood) {
    case 'happy':
      return 'text-yellow-500';
    case 'sad':
      return 'text-blue-500';
    case 'angry':
      return 'text-red-500';
    default:
      return 'text-purple-500';
  }
};

export default ChatMessage;
