
import React from 'react';
import { Mood } from '@/types';

interface EmojiSelectorProps {
  onSelectMood: (mood: Mood) => void;
}

const EmojiSelector: React.FC<EmojiSelectorProps> = ({ onSelectMood }) => {
  const emojis = [
    { mood: 'happy' as Mood, emoji: '😊', label: 'Happy' },
    { mood: 'sad' as Mood, emoji: '😔', label: 'Sad' },
    { mood: 'neutral' as Mood, emoji: '😐', label: 'Neutral' },
    { mood: 'angry' as Mood, emoji: '😠', label: 'Angry' },
  ];

  return (
    <div className="flex flex-wrap gap-2 p-1">
      {emojis.map(({ mood, emoji, label }) => (
        <button
          key={mood}
          className="emoji-selector p-2 rounded-lg hover:bg-accent text-center"
          onClick={() => onSelectMood(mood)}
          aria-label={`Select ${label} mood`}
        >
          <div className="text-2xl mb-1">{emoji}</div>
          <div className="text-xs">{label}</div>
        </button>
      ))}
    </div>
  );
};

export default EmojiSelector;
