
export type User = {
  id: string;
  username: string;
  email: string;
};

export type Message = {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: Date;
  mood?: Mood;
};

export type Mood = 'happy' | 'sad' | 'neutral' | 'angry';

export type Video = {
  id: string;
  title: string;
  description: string;
  url: string;
  mood: Mood;
  thumbnailUrl?: string;
  language?: string;
};

export type Feedback = {
  id: string;
  userId: string;
  messageId: string;
  rating: number;
  comment?: string;
  timestamp: Date;
};

